/**
 * KEUANGANKU - penghubung Google Sheets.
 * Setup: Project Settings > Script properties > tambah  PIN = (rahasia, min. 8 karakter)
 * Lalu Deploy > New deployment > Web app (Execute as: Me, Access: Anyone).
 */
const SHEET_ID = '11ZFF7CCZMtYRWDtTvn1hKpr_6YXxM86vsjR4Ms00RxQ'; // ganti ke ID file asli nanti
const FIRST = 14; // baris data pertama (header di baris 13)
const TAB = { in: 'Pemasukan', out: 'Pengeluaran' };
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function res(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const p = JSON.parse(e.postData.contents);
    const pin = PropertiesService.getScriptProperties().getProperty('PIN');
    if (!pin || String(p.pin) !== pin) return res({ ok: false, error: 'PIN salah' });
    lock.waitLock(15000);
    const ss = SpreadsheetApp.openById(SHEET_ID);
    if (p.action === 'init') return res({ ok: true, setup: readSetup(ss), tx: { in: readTx(ss, 'in'), out: readTx(ss, 'out') } });
    const sh = ss.getSheetByName(TAB[p.type]);
    if (!sh) throw new Error('Sheet tidak ditemukan');
    if (p.action === 'del') {
      if (!(p.row >= FIRST)) throw new Error('Baris tidak valid');
      sh.getRange(p.row, 1, 1, 6).clearContent(); // dikosongkan, tidak digeser
      return res({ ok: true });
    }
    const n = Number(p.nominal);
    if (!(n > 0)) throw new Error('Nominal harus lebih dari 0');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(p.tanggal)) throw new Error('Tanggal tidak valid');
    const [y, m, d] = p.tanggal.split('-').map(Number);
    const row = [new Date(y, m - 1, d, 12), p.kategori, p.detail || '', n, p.dana, MONTHS[m - 1]];
    let r = p.row;
    if (p.action === 'add') {
      r = nextRow(sh);
      if (r > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), 100);
    } else if (!(r >= FIRST)) throw new Error('Baris tidak valid');
    sh.getRange(r, 1, 1, 6).setValues([row]);
    return res({ ok: true, row: r });
  } catch (err) {
    return res({ ok: false, error: String(err.message || err) });
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}

// baris kosong pertama (Tanggal & Nominal kosong) di bawah header
function nextRow(sh) {
  const last = Math.max(sh.getLastRow(), FIRST);
  const v = sh.getRange(FIRST, 1, last - FIRST + 1, 4).getValues();
  for (let i = 0; i < v.length; i++) if (v[i][0] === '' && v[i][3] === '') return FIRST + i;
  return last + 1;
}

function readTx(ss, t) {
  const sh = ss.getSheetByName(TAB[t]), last = sh.getLastRow(), out = [];
  if (last < FIRST) return out;
  const tz = ss.getSpreadsheetTimeZone();
  sh.getRange(FIRST, 1, last - FIRST + 1, 6).getValues().forEach((v, i) => {
    const n = typeof v[3] === 'number' ? v[3] : Number(String(v[3]).replace(/[^\d-]/g, ''));
    if (v[0] === '' && !n) return;
    let d = '';
    if (v[0]) { const x = v[0] instanceof Date ? v[0] : new Date(v[0]); if (!isNaN(x)) d = Utilities.formatDate(x, tz, 'yyyy-MM-dd'); }
    if (!d) return;
    out.push({ row: FIRST + i, t: t, d: d, k: String(v[1]), c: String(v[2]), n: n || 0, w: String(v[4]) });
  });
  return out;
}

// daftar kategori & jenis dana dibaca dari tab "Setup" (header di baris 3, kolom B:I)
function readSetup(ss) {
  const sh = ss.getSheets().find(s => s.getName().indexOf('Setup') === 0);
  if (!sh) throw new Error('Tab Setup tidak ditemukan');
  const v = sh.getRange(3, 2, 40, 8).getValues();
  const h = v[0].map(x => String(x).trim().toLowerCase());
  const col = k => { const j = h.findIndex(x => x.indexOf(k) === 0); return j < 0 ? [] : v.slice(1).map(r => String(r[j]).trim()).filter(Boolean); };
  return { wallets: col('jenis dana'), in: col('income'), out: [['Needs', col('needs')], ['Wants', col('wants')], ['Saving', col('saving')]] };
}
